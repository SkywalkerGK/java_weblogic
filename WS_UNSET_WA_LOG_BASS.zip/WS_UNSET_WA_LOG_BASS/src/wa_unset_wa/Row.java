package wa_unset_wa;

public class Row {
    private String username = "";
    private String ro = "";
    private String paydue = "";
    private String group_id = "";
    private String date_alert = "";
    private String url = "";
    private String comments = "";
    private String lastdate = "";
    private String useroper = "";
    private String desclog = "";
    
    public void set_type_username(String username){
        this.username = username;
        }
    public String get_value_username(){
        return username;
        }
    public void set_type_ro(String ro){
        this.ro = ro;
        }
    public String get_value_ro(){
        return ro;
        }    
    public void set_type_paydue(String paydue){
        this.paydue = paydue;
        }
    public String get_value_paydue(){
        return paydue;
        }
    public void set_type_group_id(String group_id){
        this.group_id = group_id;
        }
    public String get_value_group_id(){
        return group_id;
        }
    public void set_type_date_alert(String date_alert){
        this.date_alert = date_alert;
        }
    public String get_value_date_alert(){
        return date_alert;
        }
    public void set_type_url(String url){
        this.url = url;
        }
    public String get_value_url(){
        return url;
        }
    public void set_type_comments(String comments){
        this.comments = comments;
        }
    public String get_value_comments(){
        return comments;
        }
    public void set_type_lastdate(String lastdate){
        this.lastdate = lastdate;
        }
    public String get_value_lastdate(){
        return lastdate;
        }
    public void set_type_useroper(String useroper){
        this.useroper = useroper;
        }
    public String get_value_useroper(){
        return useroper;
        }
    public void set_type_desclog(String desclog){
        this.desclog = desclog;
        }
    public String get_value_desclog(){
        return desclog;
        }
    
    
    
}
